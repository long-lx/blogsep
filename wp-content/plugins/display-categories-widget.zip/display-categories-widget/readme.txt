=== Display Categories Widget ===
Contributors: iteamweb
Donate link: 
Tags: categories, widget, list categories
Requires at least: 3.3
Tested up to: 3.5
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display Categories Widget will display Child categories on your sidebar. Can be placed on widget in sidebar.

== Description ==

Display Categories Widget will display Child categories on your sidebar. Can be placed on widget in sidebar.

[youtube http://www.youtube.com/watch?v=hFwz-yDu710]

== Installation ==

1. Upload display-categories-widget folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to widgets page
4. Drag and drop the widget where ever you need
5. Choose the parent category to display the child categories in the front end

== Frequently asked questions ==

= Will the plugin show parent category? =

Yes its optional, if you need to make parent category visible you can enable from the widget

= Is the category sorted? =

The sorting order is ascending and it sorts on the name of the category

== Screenshots ==

1. This is how the widget will appear on your screen, you can add design to the class
2. On the backend widget configuration can be made like this

== Changelog ==

= 1.0.8 =
* Displaying the list of categories in columnwise (Optional)

= 1.0.7 =
* If nothing is selected then all categories will be displayed. Removal of deprecated functions

= 1.0.6 =
* Optional display for Dropdown or List view of categories


= 1.0.5 =
* Display Number of post in each categories

= 1.0.4 =
* Display Empty categories Option

= 1.0.3 =
* Display parent category show/hide option

= 1.0.2 =
* Limit the number of categories that is displayed

= 1.0.1 =
* Description Updated

= 1.0 =
* Initial release.

== Upgrade notice ==



== Arbitrary section 1 ==

